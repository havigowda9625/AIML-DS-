"""
CatBoost Classifier – Telco Customer Churn
Full Training + Evaluation + Pickle Save & Load
"""

# =========================================================
# 1. IMPORTS
# =========================================================
import pandas as pd
import numpy as np
import pickle

from catboost import CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score, classification_report

# =========================================================
# 2. LOAD DATA
# =========================================================
df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")

# Fix TotalCharges
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df.dropna(inplace=True)

# Encode target
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

# Drop ID column
df.drop(columns=["customerID"], inplace=True)

# =========================================================
# 3. FEATURES & TARGET
# =========================================================
X = df.drop("Churn", axis=1)
y = df["Churn"]

# CatBoost handles categorical features natively
cat_features = X.select_dtypes(include=["object"]).columns.tolist()

print("Categorical features:")
print(cat_features)

# =========================================================
# 4. TRAIN / TEST SPLIT
# =========================================================
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    stratify=y,
    random_state=42
)

# =========================================================
# 5. CATBOOST MODEL
# =========================================================
model = CatBoostClassifier(
    iterations=500,
    depth=6,
    learning_rate=0.05,
    loss_function="Logloss",
    eval_metric="AUC",
    random_seed=42,
    verbose=100
)

# =========================================================
# 6. TRAIN MODEL
# =========================================================
model.fit(
    X_train,
    y_train,
    cat_features=cat_features,
    eval_set=(X_test, y_test),
    use_best_model=True
)

# =========================================================
# 7. EVALUATION
# =========================================================
y_pred = model.predict(X_test)
y_proba = model.predict_proba(X_test)[:, 1]

accuracy = accuracy_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_proba)

print("\nCatBoost Performance")
print("-" * 40)
print(f"Accuracy : {accuracy:.4f}")
print(f"ROC-AUC  : {roc_auc:.4f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# =========================================================
# 8. SAVE MODEL (NATIVE CATBOOST FORMAT)
# =========================================================
model.save_model("catboost_telco_churn.cbm")
print("\n✅ Model saved as catboost_telco_churn.cbm")

# =========================================================
# 9. SAVE MODEL (PICKLE)
# =========================================================
with open("catboost_telco_churn.pkl", "wb") as f:
    pickle.dump(model, f)

print("✅ Model also saved as catboost_telco_churn.pkl")

# =========================================================
# 10. LOAD PICKLE MODEL (VERIFY)
# =========================================================
with open("catboost_telco_churn.pkl", "rb") as f:
    loaded_model = pickle.load(f)

# =========================================================
# 11. TEST LOADED MODEL
# =========================================================
sample_X = X_test.iloc[:5]

sample_pred = loaded_model.predict(sample_X)
sample_proba = loaded_model.predict_proba(sample_X)[:, 1]

print("\nLoaded Model Test Prediction")
print("-" * 40)
print("Predictions :", sample_pred)
print("Probabilities:", sample_proba)
