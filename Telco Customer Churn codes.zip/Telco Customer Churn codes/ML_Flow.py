"""
MLflow Tracking – Telco Customer Churn
5 Models + Pickle Artifacts
"""

import pandas as pd
import numpy as np
import pickle
import mlflow

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from catboost import CatBoostClassifier

# =========================================================
# LOAD DATA
# =========================================================
df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")

df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df.dropna(inplace=True)
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})
df.drop(columns=["customerID"], inplace=True)

X = df.drop("Churn", axis=1)
y = df["Churn"]

cat_cols = X.select_dtypes(include="object").columns.tolist()
num_cols = X.select_dtypes(exclude="object").columns.tolist()

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

mlflow.set_experiment("Telco_Churn_Models_Pickle")

# =========================================================
# HELPER FUNCTION
# =========================================================
def train_log_model(name, pipeline):
    with mlflow.start_run(run_name=name):
        pipeline.fit(X_train, y_train)

        y_pred = pipeline.predict(X_test)
        y_proba = pipeline.predict_proba(X_test)[:, 1]

        acc = accuracy_score(y_test, y_pred)
        auc = roc_auc_score(y_test, y_proba)

        mlflow.log_metric("accuracy", acc)
        mlflow.log_metric("roc_auc", auc)

        # Save pickle
        filename = f"{name}.pkl"
        with open(filename, "wb") as f:
            pickle.dump(pipeline, f)

        mlflow.log_artifact(filename)
        print(f"✅ {name} logged | Accuracy={acc:.4f} AUC={auc:.4f}")

# =========================================================
# 1. LOGISTIC REGRESSION
# =========================================================
lr_pipeline = Pipeline([
    ("prep", ColumnTransformer([
        ("num", StandardScaler(), num_cols),
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols)
    ])),
    ("model", LogisticRegression(max_iter=1000, class_weight="balanced"))
])
train_log_model("LogisticRegression", lr_pipeline)

# =========================================================
# 2. DECISION TREE
# =========================================================
dt_pipeline = Pipeline([
    ("prep", ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ("num", "passthrough", num_cols)
    ])),
    ("model", DecisionTreeClassifier(
        max_depth=8,
        min_samples_split=50,
        min_samples_leaf=20,
        class_weight="balanced",
        random_state=42
    ))
])
train_log_model("DecisionTree", dt_pipeline)

# =========================================================
# 3. RANDOM FOREST
# =========================================================
rf_pipeline = Pipeline([
    ("prep", ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ("num", "passthrough", num_cols)
    ])),
    ("model", RandomForestClassifier(
        n_estimators=300,
        max_depth=12,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1
    ))
])
train_log_model("RandomForest", rf_pipeline)

# =========================================================
# 4. XGBOOST
# =========================================================
scale_pos_weight = (y == 0).sum() / (y == 1).sum()

xgb_pipeline = Pipeline([
    ("prep", ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ("num", "passthrough", num_cols)
    ])),
    ("model", XGBClassifier(
        n_estimators=400,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="binary:logistic",
        eval_metric="auc",
        scale_pos_weight=scale_pos_weight,
        random_state=42,
        n_jobs=-1
    ))
])
train_log_model("XGBoost", xgb_pipeline)

# =========================================================
# 5. CATBOOST (NO ENCODING)
# =========================================================
with mlflow.start_run(run_name="CatBoost"):
    cat_model = CatBoostClassifier(
        iterations=500,
        depth=6,
        learning_rate=0.05,
        loss_function="Logloss",
        eval_metric="AUC",
        random_seed=42,
        verbose=100
    )

    cat_model.fit(
        X_train, y_train,
        cat_features=cat_cols,
        eval_set=(X_test, y_test),
        use_best_model=True
    )

    y_pred = cat_model.predict(X_test)
    y_proba = cat_model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba)

    mlflow.log_metric("accuracy", acc)
    mlflow.log_metric("roc_auc", auc)

    with open("CatBoost.pkl", "wb") as f:
        pickle.dump(cat_model, f)

    mlflow.log_artifact("CatBoost.pkl")
    print(f"✅ CatBoost logged | Accuracy={acc:.4f} AUC={auc:.4f}")
