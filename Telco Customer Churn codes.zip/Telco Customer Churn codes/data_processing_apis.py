"""
Data Processing APIs – Telco Customer Churn
Includes:
1. Null Value Count
2. Outlier Count (IQR)
3. Class Imbalance → Undersampling
4. Class Imbalance → Oversampling

NO imblearn dependency (pure pandas)
"""

from flask import Flask, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
import warnings

warnings.filterwarnings("ignore")

# =========================================================
# APP SETUP
# =========================================================
app = Flask(__name__)
CORS(app)

# =========================================================
# LOAD DATA
# =========================================================
print("Loading dataset...")
df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")

# Fix TotalCharges
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")

# Clean Churn column
df["Churn"] = df["Churn"].astype(str).str.strip()

# Convert SeniorCitizen
df["SeniorCitizen"] = df["SeniorCitizen"].map({0: "No", 1: "Yes"})

# =========================================================
# 1. NULL VALUE COUNT
# =========================================================
@app.route("/api/null_value_count", methods=["GET"])
def null_value_count():
    null_counts = df.isnull().sum()
    null_percent = (null_counts / len(df)) * 100

    result = {
        col: {
            "count": int(null_counts[col]),
            "percentage": round(null_percent[col], 2)
        }
        for col in df.columns if null_counts[col] > 0
    }

    return jsonify({
        "status": "success",
        "total_rows": int(len(df)),
        "columns_with_nulls": list(result.keys()),
        "null_details": result
    })

# =========================================================
# 2. OUTLIER COUNT (IQR METHOD)
# =========================================================
@app.route("/api/outlier_count", methods=["GET"])
def outlier_count():
    numeric_cols = df.select_dtypes(include=np.number).columns
    outliers = {}

    for col in numeric_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1

        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR

        count = int(((df[col] < lower) | (df[col] > upper)).sum())
        if count > 0:
            outliers[col] = count

    return jsonify({
        "status": "success",
        "method": "IQR",
        "outlier_count": outliers
    })

# =========================================================
# 3. CLASS IMBALANCE → UNDERSAMPLING
# =========================================================
@app.route("/api/imbalancetobalance-undersampling", methods=["GET"])
def undersampling():
    majority = df[df["Churn"] == "No"]
    minority = df[df["Churn"] == "Yes"]

    majority_sampled = majority.sample(
        n=len(minority),
        random_state=42
    )

    balanced_df = pd.concat([majority_sampled, minority])

    return jsonify({
        "status": "success",
        "method": "Random Undersampling (pandas)",
        "before": {
            "No": int(len(majority)),
            "Yes": int(len(minority)),
            "total": int(len(df))
        },
        "after": {
            "No": int(len(majority_sampled)),
            "Yes": int(len(minority)),
            "total": int(len(balanced_df))
        }
    })

# =========================================================
# 4. CLASS IMBALANCE → OVERSAMPLING
# =========================================================
@app.route("/api/imbalancetobalance-oversampling", methods=["GET"])
def oversampling():
    majority = df[df["Churn"] == "No"]
    minority = df[df["Churn"] == "Yes"]

    minority_sampled = minority.sample(
        n=len(majority),
        replace=True,
        random_state=42
    )

    balanced_df = pd.concat([majority, minority_sampled])

    return jsonify({
        "status": "success",
        "method": "Random Oversampling (pandas)",
        "before": {
            "No": int(len(majority)),
            "Yes": int(len(minority)),
            "total": int(len(df))
        },
        "after": {
            "No": int(len(majority)),
            "Yes": int(len(minority_sampled)),
            "total": int(len(balanced_df))
        }
    })

# =========================================================
# RUN SERVER
# =========================================================
if __name__ == "__main__":
    print("\n🚀 Data Processing API running:")
    print("http://127.0.0.1:5000/api/null_value_count")
    print("http://127.0.0.1:5000/api/outlier_count")
    print("http://127.0.0.1:5000/api/imbalancetobalance-undersampling")
    print("http://127.0.0.1:5000/api/imbalancetobalance-oversampling")
    app.run(host="127.0.0.1", port=5000, debug=True)
