# =========================================================
# 1. IMPORTS
# =========================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, roc_auc_score
)
from sklearn.ensemble import RandomForestClassifier

sns.set(style="whitegrid")
plt.rcParams["figure.figsize"] = (8, 5)

# =========================================================
# 2. LOAD DATA
# =========================================================
df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")

print("Shape:", df.shape)
print(df.head())

# =========================================================
# 3. DATA CLEANING
# =========================================================

# Convert TotalCharges to numeric
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")

# Drop missing
df.dropna(inplace=True)

# Drop customerID (not useful)
df.drop(columns=["customerID"], inplace=True)

# Encode target
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

# =========================================================
# 4. BASIC EDA
# =========================================================

# Target distribution
sns.countplot(x="Churn", data=df)
plt.title("Churn Distribution")
plt.show()

print("\nChurn Rate:")
print(df["Churn"].value_counts(normalize=True))

# =========================================================
# 5. TENURE ANALYSIS
# =========================================================
sns.boxplot(x="Churn", y="tenure", data=df)
plt.title("Tenure vs Churn")
plt.show()

sns.histplot(data=df, x="tenure", hue="Churn", bins=30, kde=True)
plt.show()

# =========================================================
# 6. CONTRACT TYPE
# =========================================================
sns.countplot(x="Contract", hue="Churn", data=df)
plt.title("Contract vs Churn")
plt.xticks(rotation=15)
plt.show()

print(pd.crosstab(df["Contract"], df["Churn"], normalize="index"))

# =========================================================
# 7. MONTHLY CHARGES
# =========================================================
sns.boxplot(x="Churn", y="MonthlyCharges", data=df)
plt.title("Monthly Charges vs Churn")
plt.show()

# =========================================================
# 8. PAYMENT METHOD
# =========================================================
sns.countplot(x="PaymentMethod", hue="Churn", data=df)
plt.xticks(rotation=30)
plt.show()

# =========================================================
# 9. SERVICE ADD-ONS
# =========================================================
services = [
    "OnlineSecurity", "OnlineBackup",
    "DeviceProtection", "TechSupport",
    "StreamingTV", "StreamingMovies"
]

for col in services:
    sns.countplot(x=col, hue="Churn", data=df)
    plt.title(f"{col} vs Churn")
    plt.xticks(rotation=15)
    plt.show()

# =========================================================
# 10. FEATURE ENGINEERING
# =========================================================
df["Charges_per_tenure"] = df["MonthlyCharges"] / (df["tenure"] + 1)

# =========================================================
# 11. CORRELATION
# =========================================================
num_cols = ["tenure", "MonthlyCharges", "TotalCharges", "Charges_per_tenure", "Churn"]
sns.heatmap(df[num_cols].corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()

# =========================================================
# 12. PREPARE DATA FOR MODEL
# =========================================================
X = df.drop("Churn", axis=1)
y = df["Churn"]

cat_cols = X.select_dtypes(include="object").columns.tolist()
num_cols = X.select_dtypes(exclude="object").columns.tolist()

preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ("num", "passthrough", num_cols)
    ]
)

# =========================================================
# 13. MODEL PIPELINE
# =========================================================
model = RandomForestClassifier(
    n_estimators=300,
    max_depth=12,
    min_samples_split=10,
    class_weight="balanced",
    random_state=42
)

pipe = Pipeline([
    ("prep", preprocessor),
    ("model", model)
])

# =========================================================
# 14. TRAIN / TEST SPLIT
# =========================================================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

pipe.fit(X_train, y_train)

# =========================================================
# 15. EVALUATION
# =========================================================
y_pred = pipe.predict(X_test)
y_prob = pipe.predict_proba(X_test)[:, 1]

print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("\nROC-AUC:", roc_auc_score(y_test, y_prob))
print("\nClassification Report:\n", classification_report(y_test, y_pred))

sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt="d")
plt.title("Confusion Matrix")
plt.show()
