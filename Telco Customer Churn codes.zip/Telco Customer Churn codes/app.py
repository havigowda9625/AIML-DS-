from flask import Flask, jsonify
import pandas as pd
import numpy as np

# -------------------------------------------------
# APP SETUP
# -------------------------------------------------
app = Flask(__name__)

# -------------------------------------------------
# LOAD DATA
# -------------------------------------------------
try:
    df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")
except Exception as e:
    print("❌ CSV NOT FOUND OR INVALID")
    raise e

# Fix columns
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df["Churn"] = df["Churn"].astype(str).str.strip()

# -------------------------------------------------
# 1. NULL VALUE COUNT
# -------------------------------------------------
@app.route("/api/null_value_count", methods=["GET"])
def null_value_count():
    return jsonify({
        "null_value_count": df.isnull().sum().to_dict()
    })

# -------------------------------------------------
# 2. OUTLIER COUNT (IQR METHOD)
# -------------------------------------------------
@app.route("/api/outlier_count", methods=["GET"])
def outlier_count():
    result = {}
    numeric_cols = df.select_dtypes(include=np.number).columns

    for col in numeric_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        result[col] = int(((df[col] < lower) | (df[col] > upper)).sum())

    return jsonify({
        "outlier_count": result
    })

# -------------------------------------------------
# 3. CLASS IMBALANCE → UNDERSAMPLE
# -------------------------------------------------
@app.route("/api/imbalancetobalance/undersample", methods=["GET"])
def undersample():
    majority = df[df["Churn"] == "No"]
    minority = df[df["Churn"] == "Yes"]

    if len(minority) == 0:
        return jsonify({"error": "No minority class found"})

    majority_sampled = majority.sample(
        n=len(minority),
        random_state=42
    )

    return jsonify({
        "before": {
            "No": int(len(majority)),
            "Yes": int(len(minority))
        },
        "after": {
            "No": int(len(majority_sampled)),
            "Yes": int(len(minority))
        }
    })

# -------------------------------------------------
# 4. CLASS IMBALANCE → OVERSAMPLE
# -------------------------------------------------
@app.route("/api/imbalancetobalance/oversample", methods=["GET"])
def oversample():
    majority = df[df["Churn"] == "No"]
    minority = df[df["Churn"] == "Yes"]

    if len(minority) == 0:
        return jsonify({"error": "No minority class found"})

    minority_sampled = minority.sample(
        n=len(majority),
        replace=True,
        random_state=42
    )

    return jsonify({
        "before": {
            "No": int(len(majority)),
            "Yes": int(len(minority))
        },
        "after": {
            "No": int(len(majority)),
            "Yes": int(len(minority_sampled))
        }
    })

# -------------------------------------------------
# RUN SERVER
# -------------------------------------------------
if __name__ == "__main__":
    print("✅ Flask API running")
    print("➡ http://127.0.0.1:5000/api/null_value_count")
    print("➡ http://127.0.0.1:5000/api/outlier_count")
    print("➡ http://127.0.0.1:5000/api/imbalancetobalance/undersample")
    print("➡ http://127.0.0.1:5000/api/imbalancetobalance/oversample")
    app.run(host="127.0.0.1", port=5000, debug=True)
