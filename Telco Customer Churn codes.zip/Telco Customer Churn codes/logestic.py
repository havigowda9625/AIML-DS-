"""
Logistic Regression – Telco Customer Churn
Full Pipeline with Pickle Save & Load
"""

# =========================================================
# 1. IMPORTS
# =========================================================
import pandas as pd
import numpy as np
import pickle

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score, classification_report
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# =========================================================
# 2. LOAD DATA
# =========================================================
df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")

# Fix TotalCharges
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df.dropna(inplace=True)

# Encode target
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

# Drop ID column
df.drop(columns=["customerID"], inplace=True)

# =========================================================
# 3. FEATURES & TARGET
# =========================================================
X = df.drop("Churn", axis=1)
y = df["Churn"]

cat_cols = X.select_dtypes(include="object").columns.tolist()
num_cols = X.select_dtypes(exclude="object").columns.tolist()

# =========================================================
# 4. PREPROCESSING
# =========================================================
preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), num_cols),
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols)
    ]
)

# =========================================================
# 5. LOGISTIC REGRESSION MODEL
# =========================================================
model = LogisticRegression(
    max_iter=1000,
    class_weight="balanced",
    solver="lbfgs"
)

pipeline = Pipeline(steps=[
    ("preprocess", preprocessor),
    ("model", model)
])

# =========================================================
# 6. TRAIN / TEST SPLIT
# =========================================================
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    stratify=y,
    random_state=42
)

# =========================================================
# 7. TRAIN MODEL
# =========================================================
pipeline.fit(X_train, y_train)

# =========================================================
# 8. EVALUATION
# =========================================================
y_pred = pipeline.predict(X_test)
y_proba = pipeline.predict_proba(X_test)[:, 1]

accuracy = accuracy_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_proba)

print("\nLogistic Regression Performance")
print("-" * 40)
print(f"Accuracy : {accuracy:.4f}")
print(f"ROC-AUC  : {roc_auc:.4f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# =========================================================
# 9. SAVE MODEL (PICKLE)
# =========================================================
with open("logistic_regression_model.pkl", "wb") as f:
    pickle.dump(pipeline, f)

print("\n✅ Model saved as logistic_regression_model.pkl")

# =========================================================
# 10. LOAD MODEL (VERIFY PICKLE)
# =========================================================
with open("logistic_regression_model.pkl", "rb") as f:
    loaded_model = pickle.load(f)

# =========================================================
# 11. TEST LOADED MODEL
# =========================================================
sample_X = X_test.iloc[:5]

sample_pred = loaded_model.predict(sample_X)
sample_proba = loaded_model.predict_proba(sample_X)[:, 1]

print("\nLoaded Model Test Prediction")
print("-" * 40)
print("Predictions :", sample_pred)
print("Probabilities:", sample_proba)
