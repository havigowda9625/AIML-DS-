"""
XGBoost Classifier – Telco Customer Churn
Full Pipeline with Pickle Save & Load
"""

# =========================================================
# 1. IMPORTS
# =========================================================
import pandas as pd
import numpy as np
import pickle

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score, classification_report
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

from xgboost import XGBClassifier

# =========================================================
# 2. LOAD DATA
# =========================================================
df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")

# Fix TotalCharges
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df.dropna(inplace=True)

# Encode target
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

# Drop ID column
df.drop(columns=["customerID"], inplace=True)

# =========================================================
# 3. FEATURES & TARGET
# =========================================================
X = df.drop("Churn", axis=1)
y = df["Churn"]

cat_cols = X.select_dtypes(include="object").columns.tolist()
num_cols = X.select_dtypes(exclude="object").columns.tolist()

# =========================================================
# 4. PREPROCESSING
# =========================================================
preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ("num", "passthrough", num_cols)
    ]
)

# =========================================================
# 5. HANDLE CLASS IMBALANCE
# =========================================================
scale_pos_weight = (y == 0).sum() / (y == 1).sum()

# =========================================================
# 6. XGBOOST MODEL
# =========================================================
model = XGBClassifier(
    n_estimators=400,
    max_depth=6,
    learning_rate=0.05,
    subsample=0.8,
    colsample_bytree=0.8,
    objective="binary:logistic",
    eval_metric="auc",
    scale_pos_weight=scale_pos_weight,
    random_state=42,
    n_jobs=-1,
    use_label_encoder=False
)

pipeline = Pipeline(steps=[
    ("preprocess", preprocessor),
    ("model", model)
])

# =========================================================
# 7. TRAIN / TEST SPLIT
# =========================================================
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    stratify=y,
    random_state=42
)

# =========================================================
# 8. TRAIN MODEL
# =========================================================
pipeline.fit(X_train, y_train)

# =========================================================
# 9. EVALUATION
# =========================================================
y_pred = pipeline.predict(X_test)
y_proba = pipeline.predict_proba(X_test)[:, 1]

accuracy = accuracy_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_proba)

print("\nXGBoost Performance")
print("-" * 40)
print(f"Accuracy : {accuracy:.4f}")
print(f"ROC-AUC  : {roc_auc:.4f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# =========================================================
# 10. SAVE MODEL (PICKLE)
# =========================================================
with open("xgboost_model.pkl", "wb") as f:
    pickle.dump(pipeline, f)

print("\n✅ Model saved as xgboost_model.pkl")

# =========================================================
# 11. LOAD MODEL (VERIFY PICKLE)
# =========================================================
with open("xgboost_model.pkl", "rb") as f:
    loaded_model = pickle.load(f)

# =========================================================
# 12. TEST LOADED MODEL
# =========================================================
sample_X = X_test.iloc[:5]

sample_pred = loaded_model.predict(sample_X)
sample_proba = loaded_model.predict_proba(sample_X)[:, 1]

print("\nLoaded Model Test Prediction")
print("-" * 40)
print("Predictions :", sample_pred)
print("Probabilities:", sample_proba)
