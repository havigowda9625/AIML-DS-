"""
Comprehensive Exploratory Data Analysis (EDA)
Telco Customer Churn Dataset
Microsoft Fluent Color Palette
Green → Red → Remaining Colors
All plots saved as PNG
"""

# =========================================================
# 1. IMPORTS
# =========================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

# =========================================================
# 2. MICROSOFT FLUENT COLOR PALETTE (ORDERED)
# =========================================================
MS_GREEN  = "#107C10"   # 1st  (No Churn)
MS_RED    = "#D13438"   # 2nd  (Churn)
MS_BLUE   = "#0078D4"
MS_PURPLE = "#5C2D91"
MS_TEAL   = "#038387"
MS_ORANGE = "#CA5010"
MS_GRAY   = "#605E5C"

MS_PALETTE = [
    MS_GREEN,
    MS_RED,
    MS_BLUE,
    MS_PURPLE,
    MS_TEAL,
    MS_ORANGE,
    MS_GRAY
]

# =========================================================
# 3. GLOBAL STYLING (APPLIED TO ALL PLOTS)
# =========================================================
sns.set_theme(style="whitegrid", palette=MS_PALETTE)
plt.rcParams["axes.prop_cycle"] = plt.cycler(color=MS_PALETTE)
plt.rcParams["figure.figsize"] = (12, 8)
plt.rcParams["font.size"] = 10
plt.rcParams["axes.facecolor"] = "#F3F2F1"
plt.rcParams["grid.color"] = "#E1DFDD"
plt.rcParams["grid.linestyle"] = "--"

# =========================================================
# 4. OUTPUT DIRECTORY
# =========================================================
output_dir = Path("eda_graphs")
output_dir.mkdir(exist_ok=True)

# =========================================================
# 5. LOAD DATA
# =========================================================
df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")

# =========================================================
# 6. DATA CLEANING
# =========================================================
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df.dropna(inplace=True)

df["SeniorCitizen"] = df["SeniorCitizen"].map({0: "No", 1: "Yes"})

# Lock churn order → Green first, Red second
df["Churn"] = pd.Categorical(
    df["Churn"],
    categories=["No", "Yes"],
    ordered=True
)

# =========================================================
# 7. TARGET DISTRIBUTION
# =========================================================
sns.countplot(data=df, x="Churn")
plt.title("Customer Churn Count", fontweight="bold")
plt.savefig(output_dir / "01_churn_count.png", dpi=300)
plt.close()

# =========================================================
# 8. DEMOGRAPHICS
# =========================================================
for col, fname in [
    ("gender", "02_gender_churn.png"),
    ("SeniorCitizen", "03_senior_churn.png"),
    ("Partner", "04_partner_churn.png"),
    ("Dependents", "05_dependents_churn.png")
]:
    pd.crosstab(df[col], df["Churn"]).plot(kind="bar")
    plt.title(f"{col} vs Churn", fontweight="bold")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(output_dir / fname, dpi=300)
    plt.close()

# =========================================================
# 9. TENURE ANALYSIS
# =========================================================
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

axes[0].hist(df["tenure"], bins=40)
axes[0].set_title("Tenure Distribution")

df.boxplot(column="tenure", by="Churn", ax=axes[1])
axes[1].set_title("Tenure by Churn")
plt.suptitle("")

plt.tight_layout()
plt.savefig(output_dir / "06_tenure.png", dpi=300)
plt.close()

# =========================================================
# 10. CHARGES ANALYSIS
# =========================================================
for col, fname in [
    ("MonthlyCharges", "07_monthly_charges.png"),
    ("TotalCharges", "08_total_charges.png")
]:
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    axes[0].hist(df[col], bins=40)
    axes[0].set_title(f"{col} Distribution")

    df.boxplot(column=col, by="Churn", ax=axes[1])
    axes[1].set_title(f"{col} by Churn")
    plt.suptitle("")

    plt.tight_layout()
    plt.savefig(output_dir / fname, dpi=300)
    plt.close()

# =========================================================
# 11. CONTRACT & PAYMENT METHOD
# =========================================================
for col, fname in [
    ("Contract", "09_contract_churn.png"),
    ("PaymentMethod", "10_payment_method_churn.png")
]:
    pd.crosstab(df[col], df["Churn"]).plot(kind="bar")
    plt.title(f"{col} vs Churn", fontweight="bold")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(output_dir / fname, dpi=300)
    plt.close()

# =========================================================
# 12. INTERNET & SERVICES
# =========================================================
service_features = [
    "InternetService", "PhoneService", "MultipleLines",
    "OnlineSecurity", "OnlineBackup", "DeviceProtection",
    "TechSupport", "StreamingTV", "StreamingMovies",
    "PaperlessBilling"
]

fig, axes = plt.subplots(4, 3, figsize=(18, 18))
axes = axes.flatten()

for i, feature in enumerate(service_features):
    pd.crosstab(df[feature], df["Churn"]).plot(kind="bar", ax=axes[i])
    axes[i].set_title(feature, fontsize=11)
    axes[i].tick_params(axis="x", rotation=45)

plt.tight_layout()
plt.savefig(output_dir / "11_service_features.png", dpi=300)
plt.close()

# =========================================================
# 13. CORRELATION HEATMAP
# =========================================================
num_cols = df.select_dtypes(include=np.number)

plt.figure(figsize=(12, 10))
sns.heatmap(num_cols.corr(), annot=True, cmap="coolwarm", square=True)
plt.title("Correlation Heatmap", fontweight="bold")
plt.savefig(output_dir / "12_correlation.png", dpi=300)
plt.close()

# =========================================================
# 14. TENURE vs MONTHLY CHARGES
# =========================================================
sns.scatterplot(
    data=df,
    x="tenure",
    y="MonthlyCharges",
    hue="Churn",
    alpha=0.6
)
plt.title("Tenure vs Monthly Charges by Churn", fontweight="bold")
plt.tight_layout()
plt.savefig(output_dir / "13_tenure_vs_charges.png", dpi=300)
plt.close()

# =========================================================
# 15. CHURN RATE ANALYSIS
# =========================================================
fig, axes = plt.subplots(1, 2, figsize=(18, 6))

(df.groupby("Contract")["Churn"]
 .apply(lambda x: (x == "Yes").mean() * 100)
 .plot(kind="bar", ax=axes[0]))

axes[0].set_title("Churn Rate by Contract")

(df.groupby("PaymentMethod")["Churn"]
 .apply(lambda x: (x == "Yes").mean() * 100)
 .plot(kind="bar", ax=axes[1]))

axes[1].set_title("Churn Rate by Payment Method")

plt.tight_layout()
plt.savefig(output_dir / "14_churn_rates.png", dpi=300)
plt.close()

# =========================================================
# DONE
# =========================================================
print("=" * 70)
print("EDA COMPLETED SUCCESSFULLY")
print(f"All plots saved in folder: {output_dir}")
print("=" * 70)
